#include <stdbool.h>
#include <stdio.h>

bool is_prime(int n) {
  if (n <= 1)
    return false;
  for (int i = 2; i * i <= n; i++) {
    int j = n;
    while (j > 0) {
      j -= i;
    }
    if (j == 0)
      return false; // n делится на i
  }
  return true;
}

int largest_prime_divisor(int a) {
  if (a <= 1)
    return -1; // Ошибка, если a <= 1

  int largest = -1;
  for (int i = 2; i <= a; i++) {
    int j = a;
    while (j > 0) {
      j -= i;
    }
    if (j == 0 && is_prime(i)) { // Если i делит a и является простым
      largest = i;
    }
  }
  return largest;
}

int main() {
  int a;
  printf("Введите целое число: ");
  if (scanf("%d", &a) != 1) {
    printf("n/a\n");
    return 1;
  }

  int result = largest_prime_divisor(a);
  if (result == -1) {
    printf("n/a\n");
  } else {
    printf("Наибольший простой делитель: %d\n", result);
  }

  return 0;
}
