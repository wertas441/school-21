#include "s21_string.h"

#include <stdio.h>

void s21_strlen_test();
void s21_strcmp_test();
void s21_strcpy_test();
void s21_strcat_test();
void s21_strchr_test();
void s21_strstr_test();

void s21_strlen_test() {
    char *test_cases[] = {"Goodbye,world!", NULL, "4545454 454", ""};

    long expected_results[] = {13, 0, 11, 0};

    for (int i = 0; i < 4; i++) {
        char *input = test_cases[i];
        long result;

        if (input != NULL) {
            printf("Input: \"%s\"\n", input);
            result = s21_strlen(input);
        } else {
            result = 0;  //Не вызываем функцию для NULL, воизбежание ошибок
            printf("Input: NULL\n");
        }

        printf("Expected output: %ld\n", expected_results[i]);
        printf("Output: %ld\n", result);

        if (result == expected_results[i]) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
        printf("\n");
    }
}

// Функция для проверки s21_strcmp
void s21_strcmp_test() {
    char *str1_cases[] = {"Hello", "S2n", "bird", NULL};
    char *str2_cases[] = {"Hello", "Sun", "birds", NULL};

    int expected_results[] = {1, 0, 0, 0};

    for (int i = 0; i < 4; i++) {
        const char *str1 = str1_cases[i];
        const char *str2 = str2_cases[i];
        int result;

        if (str1 != NULL && str2 != NULL) {
            result = s21_strcmp(str1, str2);
            printf("Input: \"%s\" и \"%s\"\n", str1, str2);
        } else {
            result = 0;
            printf("Input: NULL\n");
        }

        printf("Expected output: %d\n", expected_results[i]);
        printf("Output: %d\n", result);

        if (result == expected_results[i]) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
        printf("\n");
    }
}

void s21_strcpy_test() {
    char dest[100];  // Список для копирования строки
    const char *src_cases[] = {"Hello", "Sun", "", NULL};

    const char *expected_results[] = {"Hello", "Sun", "", NULL};

    for (int i = 0; i < 4; i++) {
        const char *source = src_cases[i];

        if (source != NULL) {
            s21_strcpy(dest, source);
            printf("Input: \"%s\"\n", source);
            printf("Output: \"%s\"\n", dest);
        } else {
            printf("Input: NULL\n");
            printf("Copy not complete (NULL)\n");
        }

        if ((source == NULL && dest[0] == '\0') ||
            (source != NULL && s21_strcmp(dest, expected_results[i]) == 1)) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
        printf("\n");
    }
}

void s21_strcat_test() {
    char dest[100];
    const char *src_cases[] = {" body", "21", "? ?"};

    const char *expected_dest[] = {"Hello cat", "school21", " !! !"};

    char initial_dest[][100] = {"Hello", "school", " ?"};

    for (int i = 0; i < 3; i++) {
        s21_strcpy(dest, initial_dest[i]);

        const char *src = src_cases[i];
        if (src != NULL) {
            s21_strcat(dest, src);
            printf("Input dest: \"%s\", src: \"%s\"\n", initial_dest[i], src);
            printf("Expected output: \"%s\"\n", expected_dest[i]);
            printf("Output: \"%s\"\n", dest);
        } else {
            printf("Input: NULL\n");
        }

        if (s21_strcmp(dest, expected_dest[i]) == 1) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
        printf("\n");
    }
}

void s21_strchr_test() {
    const char *str_cases[] = {"Hello, cat!", "Test string", "", "No match"};

    const int char_cases[] = {'o', 'T', 'a', 'z', '\0'};

    const char *expected_results[] = {"o, world!", "Test string", NULL, NULL};

    for (int i = 0; i < 4; i++) {
        const char *str = str_cases[i];
        int c = char_cases[i];

        char *result = s21_strchr(str, c);

        printf("Input string: \"%s\", char: \"%c\" \n", str, c);

        if (result != NULL) {
            printf("Expected result: \"%s\"\n", expected_results[i]);
            printf("Output: \"%s\"\n", result);
        } else {
            printf("Expected result: NULL\n");
        }

        if ((result == NULL && expected_results[i] == NULL) ||
            (result != NULL && s21_strcmp(result, expected_results[i]) == 1)) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
        printf("\n");
    }
}

void s21_strstr_test() {
    const char *str_cases[] = {"Goodbye, world!", "Lamp is on the table", "", "Lamp is standing", NULL};

    const char *needle_cases[] = {"lamp", "test", "not found", "", NULL};

    const char *expected_results[] = {"cat!", "testing", NULL, "Lamp is standing", NULL};

    for (int i = 0; i < 5; i++) {
        const char *str = str_cases[i];
        const char *needle = needle_cases[i];

        char *result = s21_strstr(str, needle);

        printf("Source string: \"%s\"\n", str);
        printf("Needle str: \"%s\"\n", needle);

        if (result != NULL) {
            printf("Expected result: \"%s\"\n", expected_results[i]);
            printf("Output: \"%s\"\n", result);
        } else {
            printf("Output: NULL\n");
            printf("Output: NULL\n");
        }

        if ((result == NULL && expected_results[i] == NULL) ||
            (result != NULL && s21_strcmp(result, expected_results[i]) == 1)) {
            printf("SUCCESS\n");
        } else {
            printf("FAIL\n");
        }
        printf("\n");
    }
}

int main() {
#ifdef QUEST1
    s21_strlen_test();
#endif
#ifdef QUEST2
    s21_strcmp_test();
#endif
#ifdef QUEST3
    s21_strcpy_test();
#endif
#ifdef QUEST4
    s21_strcat_test();
#endif
#ifdef QUEST5
    s21_strchr_test();
#endif
#ifdef QUEST6
    s21_strstr_test();
#endif

    return 0;
}
