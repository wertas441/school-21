#include "s21_string.h"

#include <stdio.h>

size_t s21_strlen(const char *str) {
    size_t l = 0;
    while (str[l] != '\0') {
        l++;
    }
    return l;
}

int s21_strcmp(const char *str1, const char *str2) {
    while (*str1 && (*str1 == *str2)) {
        str1++;
        str2++;
    }
    return (int)*str1 == (int)*str2;  //Вычитает числовое значение символа по указателю. Если они равны, то
                                      //будет 0, если str1 меньше, то будет -1, иначе 1
}

char *s21_strcpy(char *dest, const char *source) {
    char *result = dest;
    while (*source != '\0') {
        *dest = *source;
        dest++;
        source++;
    }
    *dest = '\0';  // Добавляем завершающий нулевой символ
    return result;
}

char *s21_strcat(char *dest, const char *source) {
    char *result = dest;

    // Перемещаем указатель dest в конец
    while (*dest != '\0') {
        dest++;
    }
    while (*source != '\0') {
        *dest = *source;
        dest++;
        source++;
    }

    *dest = '\0';  // Добавляем завершающий нулевой символ
    return result;
}

char *s21_strchr(const char *str, char c) {
    if (str == NULL) return NULL;

    while (*str != '\0') {
        if (*str == c) {
            return (char *)str;  // Возвращаем указатель на найденный символ
        }
        str++;
    }
    if (c == '\0') {
        return (char *)str;  // Возвращаем указатель на '\0', если искали его
    }
    return NULL;  // Если символ не найден
}

char *s21_strstr(const char *str, const char *needle) {
    if (str == NULL) return NULL;

    if (*needle == '\0') {
        return (char *)str;  // Если needle пустая строка, вернуть str
    }

    while (*str != '\0') {
        const char *h = str;
        const char *n = needle;

        // Сравниваем символы str и needle
        while (*h == *n && *n != '\0') {
            h++;
            n++;
        }

        // Если конец needle достигнут, значит, нашли вхождение
        if (*n == '\0') {
            return (char *)str;
        }

        str++;
    }

    return NULL;  // Если подстрока не найдена
}
