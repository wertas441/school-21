 cd T01D01-1
 cd src
 bash ai_door_management_module.sh
 pkill -f ai_door_control.sh
 git add .
 git commit

