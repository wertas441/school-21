cd src
mv door_fi door_management_files
cd door_management_files\

mkdir door_configurations
mkdir door_logs
mkdir door_map
mv *conf door_configurations
mv *log door_logs
mv *map* door_map
cd
cd T01D01-1
cd src

git add .
git commit
git push --set-upstream origin



